const express=require('express');const http=require('http');const path=require('path');const fs=require('fs');const multer=require('multer');const {WebSocketServer}=require('ws');
const app=express(),server=http.createServer(app);const PORT=process.env.PORT||3000;const DATA=path.join(__dirname,'data');const UP=path.join(__dirname,'uploads');fs.mkdirSync(DATA,{recursive:true});fs.mkdirSync(UP,{recursive:true});
app.use(express.json({limit:'5mb'}));app.use(express.static(__dirname));
const dbFile=path.join(DATA,'db.json');let db=fs.existsSync(dbFile)?JSON.parse(fs.readFileSync(dbFile)):({cases:[],meetings:[],messages:[],files:[]});function save(){fs.writeFileSync(dbFile,JSON.stringify(db,null,2))}
app.get('/api/dashboard',(req,res)=>res.json({cases:db.cases,meetings:db.meetings,files:db.files,messages:db.messages.slice(-50)}));
app.post('/api/cases',(req,res)=>{const x={id:Date.now().toString(),createdAt:new Date().toISOString(),...req.body};db.cases.push(x);save();res.json(x)});
app.post('/api/meetings',(req,res)=>{const x={id:Date.now().toString(),createdAt:new Date().toISOString(),...req.body};db.meetings.push(x);save();res.json(x)});
const upload=multer({dest:UP,limits:{fileSize:100*1024*1024}});app.post('/api/files',upload.array('files',30),(req,res)=>{const items=req.files.map(f=>{const x={id:Date.now().toString()+Math.random().toString(16).slice(2),caseId:req.body.caseId||'',originalName:f.originalname,mime:f.mimetype,size:f.size,path:'/uploads/'+path.basename(f.path),createdAt:new Date().toISOString()};db.files.push(x);return x});save();res.json(items)});
app.use('/uploads',express.static(UP));app.get('*',(req,res)=>res.sendFile(path.join(__dirname,'index.html')));
const wss=new WebSocketServer({server,path:'/ws'});wss.on('connection',ws=>{ws.send(JSON.stringify({type:'system',text:'اتصال زنده برقرار شد'}));ws.on('message',raw=>{for(const c of wss.clients)if(c.readyState===1)c.send(raw.toString())})});
server.listen(PORT,()=>console.log(`Taha-Lawyer running at http://localhost:${PORT}`));
