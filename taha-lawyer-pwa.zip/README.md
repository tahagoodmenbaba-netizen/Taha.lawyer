# Taha-Lawyer 1.0
وب‌اپ فارسی RTL برای دفتر دیجیتال وکیل.

## امکانات پیاده‌سازی‌شده
- داشبورد و مرکز عملیات
- دفتر وکیل و ثبت جلسه با تاریخ، ساعت، محل، شماره بایگانی، موکل، موضوع و یادآور
- پرونده‌ها
- بایگانی فایل/تصویر/صوت و اتصال به پرونده
- دستیار حقوقی UI
- جستجوی حقوقی UI
- جلسه صوتی/تصویری مرورگر با getUserMedia و اشتراک صفحه
- چت آنلاین جلسه با WebSocket
- PWA و Service Worker
- خروجی پشتیبان JSON

## اجرا
Node.js 18+ نصب کنید، سپس:

    npm install
    npm start

سپس http://localhost:3000 را باز کنید.

## برای نسخه عملیاتی
برای محصول واقعی باید احراز هویت، RBAC، HTTPS، رمزنگاری فایل‌ها، PostgreSQL، فضای Object Storage، بکاپ، AV scanning، WebRTC signaling/turn server، موتور AI/RAG، منابع حقوقی دارای مجوز، OCR، تولید PDF/DOCX، پرداخت و مانیتورینگ اضافه شود.

## PWA / iPhone
این پروژه شامل manifest، Service Worker، آیکن‌های 192/512، Apple Touch Icon و متادیتای iOS است.
برای نصب روی iPhone باید پروژه روی HTTPS منتشر شود؛ سپس در Safari گزینه Share > Add to Home Screen را بزنید.
Offline Mode منابع اصلی رابط کاربری را cache می‌کند. APIها در حالت آفلاین طبیعتاً به Backend دسترسی ندارند.
